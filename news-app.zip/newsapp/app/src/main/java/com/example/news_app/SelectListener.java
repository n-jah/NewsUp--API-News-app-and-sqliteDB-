package com.example.news_app;

import com.example.news_app.models.NewsHeadLines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadLines headLines);

}
